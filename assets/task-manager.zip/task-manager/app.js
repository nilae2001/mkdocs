const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

app.set('view engine', 'ejs');

app.use(express.static('public'));

app.get('/', (req, res) => {
    const user = { name: 'John Doe' };
    const tasks = [
        { title: 'Review code', completed: true, priority: 'high' },
        { title: 'Write documentation', completed: false, priority: 'medium' },
        { title: 'Fix bugs', completed: false, priority: 'low' }
    ];

    res.render('index', { user, tasks });
});

app.listen(port, () => {
    console.log(`Task Manager app listening at http://localhost:${port}`);
});
